package com.example.backend1.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "TempSubjects")
public class TempSubjectsModel {
    @Id
    private String id;
    // Add fields based on your TempSubjects JSON structure
}