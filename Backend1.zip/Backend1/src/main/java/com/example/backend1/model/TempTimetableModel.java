package com.example.backend1.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "TempTimetable")
public class TempTimetableModel {
    @Id
    private String id;
    // Add fields based on your TempTimetable JSON structure
}